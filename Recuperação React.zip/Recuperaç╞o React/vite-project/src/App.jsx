import Cabecalho from './componentes/Cabecalho'
import Banner from './componentes/Banner'
import Galeria from './componentes/Galeria'
import Livro from './componentes/Livro'
import Rodape from './componentes/Rodape'
import './App.css'

function App() {

  return (
    <>
      <Cabecalho />
      <Banner />
      <Galeria />
      <Livro />
      <Rodape />
    </>
  )
}

export default App