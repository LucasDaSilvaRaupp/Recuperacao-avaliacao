export default function Rodape(){
    return(
        <foote>
            <p>ㅤLucas da Silva Raupp</p>
        </foote>
    )
}