export default function Galeria(){
    return(
        <div className="Galeria">
           
            <div className="item">
                <img src="1-removebg-preview.png" width="400px" height= "400px" alt="" /><center><h2>Harry Potter</h2></center>
            </div> 

            <div className="item">
                <img src="2-removebg-preview.png" width="400px" height= "400px" alt="" /><center><h2>Harry Potter</h2></center>
            </div>

            <div className="item">
                <img src="3-removebg-preview.png" width="400px" height= "400px" alt="" /><center><h2>Harry Potter</h2></center>
            </div>

            <div className="item">
                <img src="4-removebg-preview.png" width="400px" height= "400px" alt="" /><center><h2>Harry Potter</h2></center>
            </div>

            <div className="item">
                <img src="5-removebg-preview.png" width="400px" height= "400px" alt="" /><center><h2>Harry Potter</h2></center>
            </div>
           
            <div className="item">
                <img src="6.png" width="400px" height= "400px" alt="" /><center><h2>Harry Potter</h2></center>
            </div>

        </div>
    )
}