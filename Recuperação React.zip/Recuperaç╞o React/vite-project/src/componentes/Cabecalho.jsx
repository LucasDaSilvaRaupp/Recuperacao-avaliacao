export default function Cabecalho(){
    return(

        <header className="Cabecalho">
            
            <div className="item">  
                <h1>Biblioteca</h1>
            </div>
            
        </header>
    )
}