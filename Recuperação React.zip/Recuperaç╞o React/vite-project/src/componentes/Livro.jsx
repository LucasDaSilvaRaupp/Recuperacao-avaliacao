export default function Livro({titulo, descricao, autor, editora}){
     return(
        <div className="Informações">
            <div className="Livro">
            <h1>{titulo}</h1>
            <p>{descricao}</p>
            <p>{autor}</p>
            <p>{editora}</p>
        </div>
    </div>
     )
}